
package com.microsoft.Service;

import java.util.List;

import com.microsoft.Dao.MicroSoftDao;
import com.microsoft.Dto.LoginDto;
import com.microsoft.Dto.MicroSoftDto;
import com.microsoft.Dto.ProductDto;

public class MicroSoftService {
	MicroSoftDao dao = new MicroSoftDao();

	public LoginDto insertData(MicroSoftDto dto) {

		return dao.insertdata(dto);

	}

	public List<ProductDto> getAllProduct(LoginDto dto) {
		List<ProductDto> list = dao.getAllProducts(dto);

		return list;

	}

	public int addProductData(ProductDto dto) {
		MicroSoftDao microsoftdao = new MicroSoftDao();
		return microsoftdao.addproduct(dto);

	}

}
