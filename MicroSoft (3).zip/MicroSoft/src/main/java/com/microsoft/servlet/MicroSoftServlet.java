package com.microsoft.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.microsoft.Dao.MicroSoftDao;
import com.microsoft.Dto.CartDto;
import com.microsoft.Dto.LoginDto;
import com.microsoft.Dto.MicroSoftDto;
import com.microsoft.Dto.ProductDto;
import com.microsoft.Service.MicroSoftService;

public class MicroSoftServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MicroSoftServlet() {
		super();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		switch (action) {
		case "/insert":
			try {
				insertUser(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
		case "/login":
			loginUser(request, response);
			break;
		case "/products":
			getAllProducts(request, response);
			break;
		case "/productlist":
			addProduct(request, response);
			break;
		case "/addcart":
			addcart(request, response);
			break;
		default:
			response.sendRedirect("signup.jsp");
			break;
		}
	}

	private void addcart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession  session=	request.getSession();
		List<CartDto> oldcartlist=(List<CartDto>) session.getAttribute("oldcartlist");
		List<CartDto> newcartlist=new ArrayList<CartDto>();
	Integer productid=Integer.valueOf(request.getParameter("id"));
	
	CartDto cart=new CartDto();
	
	if(oldcartlist!=null && !oldcartlist.isEmpty()&& oldcartlist.size()>0) {
		newcartlist=oldcartlist;
		for(CartDto ca:newcartlist) {
			if(ca.getId()==productid) {
				request.getRequestDispatcher("cartalert.jsp").forward(request, response);
			}
		}
		
		cart.setId(productid);
		cart.setQuantity(1);
		newcartlist.add(cart);
		session.setAttribute("oldcartlist", newcartlist);
	}else {
		cart.setId(productid);
		cart.setQuantity(1);
		newcartlist.add(cart);
		session.setAttribute("oldcartlist", newcartlist);
	}
		request.getRequestDispatcher("products").forward(request, response);
	}

	private void addProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String pname = request.getParameter("name");
		String pcategory = request.getParameter("category");
		Double pprice = Double.valueOf(request.getParameter("price"));
		String pimage = request.getParameter("image");
		ProductDto productdto = new ProductDto(pname, pcategory, pprice, pimage);

		MicroSoftService micrssoftservice = new MicroSoftService();
		micrssoftservice.addProductData(productdto);
		response.sendRedirect("product.jsp");

	}

	private void getAllProducts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String user = request.getParameter("username");
		String pass = request.getParameter("password");

		LoginDto logindto = new LoginDto(user, pass);
		MicroSoftService microsoftservice = new MicroSoftService();
		List<ProductDto> productlist = microsoftservice.getAllProduct(logindto);
		System.out.println("this is from servlet >>>>>>>>>>>>>>" + productlist);
		request.setAttribute("productlist", productlist);
		request.getRequestDispatcher("product.jsp").forward(request, response);

	}

	private void loginUser(HttpServletRequest request, HttpServletResponse response) {
	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String sname = request.getParameter("name");
		String semail = request.getParameter("email");
		String smobile = request.getParameter("mobile");
		String saadhar = request.getParameter("aadhar");
		String spassword = "";

		for (int i = 0; i < 7; i++) {
			spassword += semail.charAt(i);
		}

		MicroSoftDto msdto = new MicroSoftDto(sname, semail, smobile, saadhar, spassword);
		

		MicroSoftDao msd = new MicroSoftDao();
		LoginDto inserted = msd.insertdata(msdto);
		if (inserted != null) {
			request.setAttribute("username", inserted.getUsername());
			request.setAttribute("password", inserted.getPassword());
			request.getRequestDispatcher("landing.jsp").forward(request, response);
		} else {
			response.sendRedirect("signup.jsp");
		}

	}
}
