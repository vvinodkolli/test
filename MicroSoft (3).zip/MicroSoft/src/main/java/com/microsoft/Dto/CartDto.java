package com.microsoft.Dto;

public class CartDto  extends ProductDto{
	
	private Integer quantity;

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public CartDto(int id, String name, String category, Double price, String image, Integer quantity) {
		super(id, name, category, price, image);
		this.quantity = quantity;
	}

	public CartDto() {
	}

	@Override
	public String toString() {
		return "CartDto [quantity=" + quantity + "]";
	}

}
