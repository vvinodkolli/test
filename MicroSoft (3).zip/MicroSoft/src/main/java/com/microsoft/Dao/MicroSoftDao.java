package com.microsoft.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.microsoft.Dto.LoginDto;
import com.microsoft.Dto.MicroSoftDto;
import com.microsoft.Dto.ProductDto;
import com.microsoft.util.DbConnection; // Assuming DbConnection class is in a package com.microsoft.util

public class MicroSoftDao {
	PreparedStatement ps = null;
	ResultSet rs = null;
	Connection con = DbConnection.getDbConnection();

	public LoginDto insertdata(MicroSoftDto msdto) {
		int inserted = 0;
		LoginDto logindto = new LoginDto();


		try {


			String sql = "INSERT INTO microsoft_table(name, email, mobile, aadharno, password)VALUES(?,?,?,?,?)";
			String retrivesql = "select email,password from microsoft_table where email=? and password=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, msdto.getName());
			ps.setString(2, msdto.getEmail());
			ps.setString(3, msdto.getMobile());
			ps.setString(4, msdto.getAadharno());
			ps.setString(5, msdto.getPassword());

			inserted = ps.executeUpdate();
			if (inserted != 0) {
				ps = con.prepareStatement(retrivesql);
				ps.setString(1, msdto.getEmail());
				ps.setString(2, msdto.getPassword());
				rs = ps.executeQuery();
				while (rs.next()) {
					logindto.setUsername(rs.getString(1));
					logindto.setPassword(rs.getString(2));

				}
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return logindto;
	}

	public List<ProductDto> getAllProducts(LoginDto dto) {
		String retrivesql = "select * from products_table";
		String checkingsql = "select * from microsoft_table where email=? and password=?";
		List<ProductDto> list = new ArrayList<ProductDto>();
		try {
			ps = con.prepareStatement(checkingsql);
			ps.setString(1, dto.getUsername());
			ps.setString(2, dto.getPassword());
			rs = ps.executeQuery();
			if (rs != null) {
				ps = con.prepareStatement(retrivesql);
				rs = ps.executeQuery();
				while (rs.next()) {
					ProductDto productdto = new ProductDto();
					productdto.setId(rs.getInt(1));
					productdto.setName(rs.getString(2));
					productdto.setCategory(rs.getString(3));
					productdto.setPrice(rs.getDouble(4));
					productdto.setImage(rs.getString(5));
					list.add(productdto);

				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}
	
	public int addproduct(ProductDto dto) {
		int effected=0;
		String str="insert into products_table (name, category,price,productimage) values(?,?,?,?)";
		try {
			ps=con.prepareStatement(str);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getCategory());
			ps.setDouble(3, dto.getPrice());
			ps.setString(4, dto.getImage());
			effected=	ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return effected;
		
	}
}
